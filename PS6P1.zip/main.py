#

#for count in range(1,11,1):
 # print(count)

#for number in range(11):
 # print(number)

p = float(input("Enter Principle: $"))
r = float (input("Enter Intreset rate: "))

bb = p * 1 

for count in range(1,6,1):
  i = bb * r
  eb = bb + i
  print(count," $",bb," $",eb)
  bb = eb

ti = eb - p 

print("Total interest earned: $",ti)