extt = 0
o = 0

f = open("data.txt","r")

item = f.readline()

while item != "":
  q = float(f.readline())
  p = float(f.readline())
  ext = q * p 
  extt = extt + ext
  o = o + 1
  print(item, "Quantity: ", q,  "Price: $",p, "Extended Price: $",ext)
  item = f.readline()

print("Total Extended Price: $",extt)
print("Number of Orders: ",o)

avg = extt / o

print("Average Order price: $",avg)