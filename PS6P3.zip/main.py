total = 0

f = open("data.txt","r")

name = f.readline()

while name != "":
  s = float(f.readline())
  if s >= 100000.00:
    b = s * 0.2
  elif s >= 50000.00:
    b = s * 0.15
  else:
    b = s * 0.1
  total = b + total
  print(name, "Salary: $", s, "Bonus: $",b)
  name = f.readline()

print("Total Bonuses: $", total)