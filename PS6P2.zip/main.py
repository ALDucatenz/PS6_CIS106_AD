v1 = 1
v2 = 1

print(v1)
print(v2)

for count in range(1,19,1):
  v3 = v1 + v2
  print(v3)
  v1 = v2
  v2 = v3